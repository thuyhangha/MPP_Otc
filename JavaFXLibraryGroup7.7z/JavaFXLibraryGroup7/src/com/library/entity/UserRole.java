package com.library.entity;

public enum UserRole {
    ADMINISTRATOR, LIBRARYAN, MEMBER
}
